module.exports = {
  retweet: require("./retweet"),
  favourite: require("./favourite")
}
